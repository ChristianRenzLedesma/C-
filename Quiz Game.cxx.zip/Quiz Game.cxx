#include <iostream>
#include <vector>
#include <sstream>
#include <fstream>
using namespace std;

struct Register {
    string name;
    int age;
    int number;
    int score;
};

struct Question {
    string question;
    string correct;
};

vector<Register> registers;
vector<Question> questions;

vector<string> split(const string& s, char delimiter) {
    vector<string> tokens;
    stringstream ss(s);
    string token;
    while(getline(ss, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

void saveDataToFile() {
    ofstream file("Quiz.dat");

    if (file.is_open()) {
        for (const Register& player : registers) {
            file << player.name << ',' << player.age << ',' << player.number << ',' << player.score << '\n';
        }

        for (const Question& question : questions) {
            file << question.question << '|' << question.correct << '\n';
        }

        file << "END\n";
        file.close();
        cout << "Data successfully saved to file.\n";
    } else {
        cout << "Unable to open file.\n";
    }
}

void loadDataFromFile() {
    ifstream file("Quiz.dat");

    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            vector<string> tokens = split(line, ',');
            if (tokens.size() == 4) {
                Register player;
                player.name = tokens[0];
                player.age = stoi(tokens[1]);
                player.number = stoi(tokens[2]);
                player.score = stoi(tokens[3]);
                registers.push_back(player);
            } else if (line == "END") {
                break;
            } else {
                vector<string> questionData = split(line, '|');
                if (questionData.size() == 2) {
                    Question question;
                    question.question = questionData[0];
                    question.correct = questionData[1];
                    questions.push_back(question);
                }
            }
        }
        file.close();
        cout << "Data successfully loaded from file.\n";
    } else {
        cout << "Unable to open file.\n";
    }
}


int main() {
    loadDataFromFile();
    char choice;
    while(true){
        system("cls");
        cout << "-----------------------------------------------------------------" << endl;
        cout << "                     M.I.N.I Q.U.I.Z G.A.M.E" << endl;
        cout << "-----------------------------------------------------------------" << endl;
        cout << "            OWNER OF THIS CODE: Christian Renz Ledesma" << endl;
        cout << "-----------------------------------------------------------------" << endl;
        cout << "         [1] - Add Question" << endl;
        cout << "         [2] - Register Player" << endl;
        cout << "         [3] - Start Quiz" << endl;
        cout << "         [4] - Scoreboard" << endl;
        cout << "         [5] - Player List" << endl;
        cout << "         [6] - Exit" << endl;
        cout << "-----------------------------------------------------------------" << endl;
        cout << "         Enter Chose : ";
        cin >> choice;

        switch(choice) {
            case '1': {
                 system("cls");
                cin.ignore();

                Question newQuestion;
                cout << "|=============================|" << endl;
                cout << "|       |Add Question|        |" << endl;
                cout << "|       |============|        |" << endl;
                cout << "|=============================|" << endl;
                cout << "Add Question: ";
                cin.ignore();
                getline(cin, newQuestion.question);
                cout << "Correct Answer: ";
                getline(cin, newQuestion.correct);
                cout << "Successfully added the question!" << endl;

                questions.push_back(newQuestion);
                system("pause");
                break;
            }
            case '2': {
                system("cls");
                cout << "|==============================|" << endl;
                cout << "|       |Register Form|        |" << endl;
                cout << "|       |=============|        |" << endl;
                cout << "|==============================|" << endl;
                cin.ignore();

                Register newRegister;
                cout << "Enter name: ";
                getline(cin, newRegister.name);
                cout << "Enter age: ";
                cin >> newRegister.age;
                cout << "Enter player number: ";
                cin >> newRegister.number;

                if (registers.empty()) {
                newRegister.score = 0;
                }

                registers.push_back(newRegister);
                system("pause");
                break;
           }
           case '3': {
    system("cls");
    int playerNumber;
    cout << "Enter player number to start the quiz!: ";
    cin >> playerNumber;

    system("cls");
    	bool registerFound = false;
    for (size_t i = 0; i < registers.size(); ++i) {
        if (registers[i].number == playerNumber) {
            registerFound = true;
            
            
            bool answered = false;
            while(!answered){
            	system("cls");
            	cout << "           Let's start the quiz!" << endl;
            	cout << "|==========================================|" << endl;
            cout << "|       |List of Question to solve|        |" << endl;
            cout << "|       |=========================|        |" << endl;
            cout << "|==========================================|" << endl;
            	for (size_t i = 0; i < questions.size(); ++i) {
                cout << i + 1 << ". " << questions[i].question << endl;
            }
            int chosenQuestion;
            cout << "Choose a question to answer (Enter corresponding number): ";
            cin >> chosenQuestion;
            cin.ignore();

            if (chosenQuestion <= 0 || chosenQuestion > static_cast<int>(questions.size())) {
                cout << "Invalid question number selected!" << endl;
                break;
            }
           system("cls");
            cout << "You chose: " << questions[chosenQuestion - 1].question << endl;
            cout << "Enter Your answer: ";
            string userAnswer;
            getline(cin, userAnswer);

            if (userAnswer == questions[chosenQuestion - 1].correct) {
                for (size_t i = 0; i < registers.size(); ++i) {
                    if (registers[i].number == playerNumber) {
                        registers[i].score++;
                        cout << "Correct Answer! Your score now is: " << registers[i].score << endl;
                    system("pause");
                    break;
                    }
                }
            } else {
                cout << "Incorrect Answer!" << endl;
            }
        }
    }
    if (!registerFound) {
        cout << "No registered player yet." << endl;
    }
    system("pause");
    break;
  }
            	} 

           case '4': {
               system("cls");
               cout << "-----------------------------------------------------------------" << endl;
               cout << "                    S C O R E B O A R D" << endl;
               cout << "-----------------------------------------------------------------" << endl;
               if(registers.empty()) {
                  cout << "No player registered yet." << endl;
               } else {
                cout << "Player Name\t\t\tPlayer Number\t\t\tScore" << endl;
                cout << "------------------------------------------------------------------" << endl;
                for (const Register& player : registers) {
                    cout << player.name << "\t\t\t" << player.number << "\t\t\t" << player.score << endl;
                }
               }
               system("pause");
               break;
           }
           case '5': {
               system("cls");
                cout << "|============================|" << endl;
                cout << "|       |Player List|        |" << endl;
                cout << "|       |===========|        |" << endl;
                cout << "|============================|" << endl;
                cout << "--------------------------------" << endl;
                cout << "Name                       Age" << endl;
                cout << "--------------------------------" << endl;
                for(size_t i = 0; i < registers.size(); ++i){
                    cout << i + 1 << ". " << registers[i].name << " - " << registers[i].age << endl;
                }
                system("pause");
                break;
           }
        case '6': {
            system("cls");
                cout << "|=========================|" << endl;
                cout << "|       |Goodbye!|        |" << endl;
                cout << "|       |========|        |" << endl;
                cout << "|=========================|" << endl;
                saveDataToFile();
                return 0;
        }
       }
   }
   return 0;
}